
import com.mysql.jdbc.Connection;
import com.mysql.jdbc.Statement;
import java.sql.DriverManager;


public class Javaconnet {
    public static  Connection getConnection(){
        Connection con = null;
        Statement start = null;
        
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con =(Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/math_learn","root","root");
            
        } catch (Exception e) {
            e.printStackTrace();
        } 
        return con;
    }  
}
