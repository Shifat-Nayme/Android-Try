package com.shifat.myquiz;


import android.content.Intent;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;


/**
 * A simple {@link Fragment} subclass.
 */
public class Fourthfrag extends Fragment {
    Button b1;
    int score=0;
    RadioGroup r1;
    RadioButton r2;


    public Fourthfrag() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        Bundle bundle = getArguments();
        score = bundle.getInt("tag");

        // Inflate the layout for this fragment
        View v = inflater.inflate(R.layout.fragment_fourthfrag, container, false);

        b1 = v.findViewById(R.id.button4);
        r2= v.findViewById(R.id.austria);
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(r2.isChecked())
                {
                    score = score+5;
                }

                Bundle bundle = new Bundle();
                bundle.putInt("tag",score);

                Fivthfrag fivthfrag = new Fivthfrag();
                fivthfrag.setArguments(bundle);

                FragmentTransaction transaction = getFragmentManager().beginTransaction();
                transaction.replace(R.id.mainlayout,fivthfrag);
                transaction.commit();

            }
        });



        return v;
    }

}
