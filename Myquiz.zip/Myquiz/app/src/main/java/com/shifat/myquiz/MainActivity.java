package com.shifat.myquiz;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;

import android.app.FragmentTransaction;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioGroup;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Firstfrag firstfrag = new Firstfrag();
        FragmentManager fm = getSupportFragmentManager();
        fm.beginTransaction().add(R.id.mainlayout, firstfrag).commit();


    }


}
