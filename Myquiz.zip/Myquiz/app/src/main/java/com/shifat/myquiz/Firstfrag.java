package com.shifat.myquiz;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;


public class Firstfrag extends Fragment {
    Button b1;
    RadioGroup r1;
    RadioButton r2;
    int score =0;

    public Firstfrag()
    {
        // Required empty public constructor
    }


    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v = inflater.inflate(R.layout.fragment_firstfrag, container, false);


        b1 = v.findViewById(R.id.button1);
        r2= v.findViewById(R.id.afgani);
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(r2.isChecked())
                {
                    score = score+5;
                }
                Bundle bundle = new Bundle();
                bundle.putInt("tag",score);

                Secondfrag secondfrag = new Secondfrag();
                secondfrag.setArguments(bundle);

                FragmentTransaction transaction = getFragmentManager().beginTransaction();
                transaction.replace(R.id.mainlayout,secondfrag);
                transaction.commit();

            }
        });

        return v;

    }


}
