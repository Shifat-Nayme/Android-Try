package com.shifat.myquiz;


import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;


/**
 * A simple {@link Fragment} subclass.
 */
public class Scorefrag extends Fragment {
    int score=0;
    TextView textView;


    public Scorefrag() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View v = inflater.inflate(R.layout.fragment_scorefrag, container, false);
        textView = v.findViewById(R.id.textview7);

        Bundle bundle = getArguments();
        score = bundle.getInt("tag");


        textView.setText(Integer.toString(score));


        // Inflate the layout for this fragment
        return v;
    }

}
